import React, { useState } from 'react';
import { Bot } from 'lucide-react';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { Message, CDP_PLATFORMS } from './types';

function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: 'Hello! I\'m your CDP Assistant. I can help you with questions about Segment, mParticle, Lytics, and Zeotap. How can I assist you today?',
      timestamp: new Date(),
    },
  ]);

  const handleSendMessage = (content: string) => {
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content,
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, userMessage]);

    // Simulate bot response
    setTimeout(() => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: generateResponse(content),
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, botMessage]);
    }, 1000);
  };

  const generateResponse = (question: string): string => {
    // Simple response generation logic - this would be replaced with actual NLP/search
    const lowerQuestion = question.toLowerCase();
    
    if (lowerQuestion.includes('segment') && lowerQuestion.includes('source')) {
      return 'To set up a new source in Segment:\n\n1. Log in to your Segment workspace\n2. Click on "Sources" in the navigation\n3. Click "Add Source"\n4. Search for and select your desired source type\n5. Follow the configuration steps for your specific source\n\nFor more details, you can check the official documentation: ' + CDP_PLATFORMS[0].docsUrl;
    }

    if (lowerQuestion.includes('compare') || lowerQuestion.includes('difference')) {
      return 'Each CDP has its unique strengths:\n\n- Segment excels in developer-friendly implementations and extensive integration options\n- mParticle offers robust mobile and app analytics capabilities\n- Lytics focuses on AI-powered customer insights and predictions\n- Zeotap specializes in identity resolution and data enrichment\n\nFor specific feature comparisons, please ask about particular aspects you\'re interested in.';
    }

    return 'I understand you\'re asking about CDP functionality. Could you please be more specific about which platform (Segment, mParticle, Lytics, or Zeotap) and what particular feature or task you\'re interested in?';
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
            <Bot size={24} className="text-blue-600" />
          </div>
          <h1 className="text-xl font-semibold">CDP Support Assistant</h1>
        </div>
      </header>

      <main className="flex-1 overflow-auto">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="space-y-4">
            {messages.map(message => (
              <ChatMessage key={message.id} message={message} />
            ))}
          </div>
        </div>
      </main>

      <ChatInput onSend={handleSendMessage} />
    </div>
  );
}

export default App;